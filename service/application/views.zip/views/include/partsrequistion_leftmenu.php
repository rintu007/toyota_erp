<div class="left-menu" id="sidebar">
    <a href="http://110.93.203.204:8282/twm/index.php/login/menu">Home Page</a>
    <a href="<?= base_url() ?>index.php/jpcb/index">Dashboard</a>
    <a href="<?= base_url() ?>index.php/partsinfo/index">Parts Info</a>
    <a href="<?= base_url() ?>index.php/partsrequisition/index">Requested Parts</a>
    <a href="<?= base_url() ?>index.php/partsreceived/index">Received Parts</a>
    <a href="<?= base_url() ?>index.php/partsrequisitionmechanical/index">Parts Req. Mechanical</a>
    <a href="<?= base_url() ?>index.php/partsrequisitionbodyshop/index">Parts Req. Body Shop</a>
	 <a href="http://110.93.203.204:8282/twm/customerrelations/index.php/Inquiryreplyaction/service">Inquiry from CR</a>
    <a href="http://110.93.203.204:8282/twm/index.php/login/logout">Logout</a>
</div>