<div class="left-menu" id="sidebar">
     <a href="http://110.93.203.204:8282/twm/index.php/login/menu">Home Page</a>
    <a href="<?= base_url() ?>index.php/jpcb/index">Dashboard</a>
    <a href="<?= base_url() ?>index.php/staff/index">Staff Management</a>
	 <a href="http://110.93.203.204:8282/twm/customerrelations/index.php/Inquiryreplyaction/service">Inquiry from CR</a>
    <a href="http://110.93.203.204:8282/twm/index.php/login/logout">Logout</a>

</div>