<div class="left-menu" id="sidebar">
    <a href="http://110.93.203.204:8282/twm/index.php/login/menu">Home Page</a>
    <a href="<?= base_url() ?>index.php/psfuupdate/index">PSFU Message Box</a>
    <a href="<?= base_url() ?>index.php/contactinfo/index">Contact Type Data</a>
    <a href="<?= base_url() ?>index.php/psfuresult/index">PSFU Result Data</a>
    <a href="<?= base_url() ?>index.php/psfuduration/index">Add PSFU-Duration</a>
	 <a href="http://110.93.203.204:8282/twm/customerrelations/index.php/Inquiryreplyaction/service">Inquiry</a>
    <a href="http://110.93.203.204:8282/twm/index.php/login/logout">Logout</a>
</div>
