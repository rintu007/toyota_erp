<div class="left-menu" id="sidebar">
     <a href="http://110.93.203.204:8282/twm/index.php/login/menu">Home Page</a>
    <a href="<?= base_url() ?>index.php/jpcb/index">Dashboard</a>
    <a href="<?= base_url() ?>index.php/romode/index">Add RO-Modes</a>
    <a href="<?= base_url() ?>index.php/bay/index">Bay Management</a>
    <a href="<?= base_url() ?>index.php/staff/index">Staff Management</a>
    <a href="<?= base_url() ?>index.php/staffroles/index">Staff Roles</a>
    <a href="<?= base_url() ?>index.php/financeinfo/index">Customer Type</a>    
    <a href="<?= base_url() ?>index.php/conditionconfirmation/index">5W1H</a>
    <a href="<?= base_url() ?>index.php/conditionconfirmationdetail/index">5W1H Details</a>
    <a href="<?= base_url() ?>index.php/fuelmanagement/index">Fuel Management</a>
    <a href="<?= base_url() ?>index.php/rochecklist/index">Check List Management</a>
    <a href="<?= base_url() ?>index.php/jobreferencemanual/index">Job Reference Manual</a>
    <a href="<?= base_url() ?>index.php/periodicmaintenance/index">Maintenance Package</a>
    <a href="<?= base_url() ?>index.php/periodicmaintenancedetail/index">Maintenance Details</a>
    <a href="<?= base_url() ?>index.php/categoryinfo/index">Category Management</a>
    <a href="<?= base_url() ?>index.php/jobresultexplanation/index">Job Result Type</a>
    <a href="<?= base_url() ?>index.php/qualitycheck/index">Quality Management</a>
    <a href="<?= base_url() ?>index.php/allbrands/index">Add All Brands</a>
    <a href="<?= base_url() ?>index.php/allmodels/index">Add All Models</a>
    <a href="<?= base_url() ?>index.php/allvehicles/index">Add All Vehicles</a>
    <a href="<?= base_url() ?>index.php/firquestions/index">Add FIR-Questions</a>
    <a href="<?= base_url() ?>index.php/fuelvolume/index">Add Fuel Levels</a>  
    <a href="<?= base_url() ?>index.php/insurancecompany/index">Add Ins. Company</a>  
    <a href="<?= base_url() ?>index.php/insurancecompanybranch/index">Add Ins.Branch</a>  
	 <a href="http://110.93.203.204:8282/twm/customerrelations/index.php/Inquiryreplyaction/service">Inquiry from CR</a>
    <a href="http://110.93.203.204:8282/twm/index.php/login/logout">Logout</a>
</div>