<div class="left-menu" id="sidebar">
    <!--<a href="http://localhost/dealer001/index.php/login/menu">Home Page</a>-->
    <a href="http://110.93.203.204:8282/twm/index.php/login/menu">Home Page</a>
    <a href="<?= base_url() ?>index.php/bay/index">Manage Master Data</a>
    <a href="<?= base_url() ?>index.php/jpcb/plan">JPCB</a>
    <a href="<?= base_url() ?>index.php/jpcb/asb">ASB</a>
    <a href="<?= base_url() ?>index.php/jpcb/index">Schedule Appointment</a>
    <a href="<?= base_url() ?>index.php/repairorder/index">Open RO</a>
    <a href="<?= base_url() ?>index.php/estimatemechanical/index">Create Estimate</a>
    <a href="<?= base_url() ?>index.php/partsinfo/index">Parts Requisition</a>   
    <a href="<?= base_url() ?>index.php/reportservices/index">Reports</a> 
    <a href="http://110.93.203.204:8282/twm/customerrelations/index.php/Inquiryreplyaction/service">Inquiry from CR</a>	
    <a href="http://110.93.203.204:8282/twm/index.php/login/logout">Logout</a>
</div>